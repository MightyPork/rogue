/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class EXTUnpackSubimage {

	/**
	 *  Accepted by the &lt;pname&gt; parameters of PixelStorei, GetIntegerv, and
	 *  GetFloatv:
	 */
	public static final int GL_UNPACK_ROW_LENGTH = 0xCF2,
		GL_UNPACK_SKIP_ROWS = 0xCF3,
		GL_UNPACK_SKIP_PIXELS = 0xCF4;

	private EXTUnpackSubimage() {}
}
