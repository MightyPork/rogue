/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class ARBHalfFloatPixel {

	/**
	 *  Accepted by the &lt;type&gt; parameter of DrawPixels, ReadPixels,
	 *  TexImage1D, TexImage2D, TexImage3D, GetTexImage, TexSubImage1D,
	 *  TexSubImage2D, TexSubImage3D:
	 */
	public static final int GL_HALF_FLOAT_ARB = 0x140B;

	private ARBHalfFloatPixel() {}
}
