/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class IMGTextureCompressionPvrtc {

	/**
	 *  Accepted by the &lt;internalformat&gt; parameter of CompressedTexImage2DARB
	 *  and the &lt;format&gt; parameter of CompressedTexSubImage2DARB:
	 */
	public static final int GL_COMPRESSED_RGB_PVRTC_4BPPV1_IMG = 0x8C00,
		GL_COMPRESSED_RGB_PVRTC_2BPPV1_IMG = 0x8C01,
		GL_COMPRESSED_RGBA_PVRTC_4BPPV1_IMG = 0x8C02,
		GL_COMPRESSED_RGBA_PVRTC_2BPPV1_IMG = 0x8C03;

	private IMGTextureCompressionPvrtc() {}
}
