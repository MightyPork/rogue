/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class IMGReadFormat {

	/**
	 * Accepted by the &lt;format&gt; parameter of ReadPixels: 
	 */
	public static final int GL_BGRA_IMG = 0x80E1,
		GL_UNSIGNED_SHORT_4_4_4_4_REV_IMG = 0x8365;

	private IMGReadFormat() {}
}
