/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class ARMRgba8 {

	/**
	 * Accepted by the &lt;internalformat&gt; parameter of RenderbufferStorage: 
	 */
	public static final int GL_RGBA8_OES = 0x8058;

	private ARMRgba8() {}
}
