/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESDepthTexture {

	/**
	 *  Accepted by the &lt;format&gt; parameter of TexImage2D and TexSubImage2D and
	 *  &lt;internalFormat&gt; parameter of TexImage2D:
	 */
	public static final int GL_DEPTH_COMPONENT = 0x1902;

	/**
	 * Accepted by the &lt;type&gt; parameter of TexImage2D, TexSubImage2D: 
	 */
	public static final int GL_UNSIGNED_SHORT = 0x1403,
		GL_UNSIGNED_INT = 0x1405;

	private OESDepthTexture() {}
}
