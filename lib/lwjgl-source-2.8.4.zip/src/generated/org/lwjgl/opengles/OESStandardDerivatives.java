/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengles;

import org.lwjgl.*;
import java.nio.*;

public final class OESStandardDerivatives {

	/**
	 *  Accepted by the &lt;target&gt; parameter of Hint and by the &lt;pname&gt; parameter of
	 *  GetBooleanv, GetIntegerv, GetFloatv, and GetDoublev:
	 */
	public static final int GL_FRAGMENT_SHADER_DERIVATIVE_HINT_OES = 0x8B8B;

	private OESStandardDerivatives() {}
}
