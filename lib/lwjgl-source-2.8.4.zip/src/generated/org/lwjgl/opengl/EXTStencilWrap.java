/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTStencilWrap {

	public static final int GL_INCR_WRAP_EXT = 0x8507,
		GL_DECR_WRAP_EXT = 0x8508;

	private EXTStencilWrap() {}
}
