/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class EXTVertexArrayBgra {

	/**
	 *  Accepted by the &lt;size&gt; parameter of ColorPointer,
	 *  SecondaryColorPointer, and VertexAttribPointer:
	 */
	public static final int GL_BGRA = 0x80E1;

	private EXTVertexArrayBgra() {}
}
