/* MACHINE GENERATED FILE, DO NOT EDIT */

package org.lwjgl.opengl;

import org.lwjgl.*;
import java.nio.*;

public final class SGISGenerateMipmap {

	/**
	 *  Accepted by the &lt;pname&gt; parameter of TexParameteri, TexParameterf,
	 *  TexParameteriv, TexParameterfv, GetTexParameteriv, and GetTexParameterfv.
	 */
	public static final int GL_GENERATE_MIPMAP_SGIS = 0x8191;

	/**
	 *  Accepted by the &lt;target&gt; parameter of Hint, and by the <pname>
	 *  parameter of GetBooleanv, GetIntegerv, GetFloatv, and GetDoublev.
	 */
	public static final int GL_GENERATE_MIPMAP_HINT_SGIS = 0x8192;

	private SGISGenerateMipmap() {}
}
